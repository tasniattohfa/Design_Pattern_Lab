public class MangoTree implements Tree {
    @Override
    public String getDescription() {
        return "Mango Tree";
    }
}
