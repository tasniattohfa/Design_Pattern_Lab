public class BrickHouse implements House {
    @Override
    public String getDescription() {
        return "Brick House";
    }
}
