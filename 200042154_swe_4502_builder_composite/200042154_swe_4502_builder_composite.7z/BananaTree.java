public class BananaTree implements Tree {
    @Override
    public String getDescription() {
        return "Banana Tree";
    }
}