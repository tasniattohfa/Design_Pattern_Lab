public class SwimmingPool implements WaterSource {
    @Override
    public String getDescription() {
        return "Swimming Pool";
    }
}
