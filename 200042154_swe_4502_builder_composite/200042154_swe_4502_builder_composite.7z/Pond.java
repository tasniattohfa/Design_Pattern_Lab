public class Pond implements WaterSource {
    @Override
    public String getDescription() {
        return "Pond";
    }
}