public interface Tree {
    String getDescription();
}
