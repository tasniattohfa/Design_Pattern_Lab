public class MudHouse implements House {
    @Override
    public String getDescription() {
        return "Mud House";
    }
}
