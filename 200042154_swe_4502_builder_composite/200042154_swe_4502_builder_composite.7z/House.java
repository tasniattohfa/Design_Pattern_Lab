public interface House {
    String getDescription();
}

