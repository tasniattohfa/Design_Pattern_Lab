public interface WaterSource {
    String getDescription();
}