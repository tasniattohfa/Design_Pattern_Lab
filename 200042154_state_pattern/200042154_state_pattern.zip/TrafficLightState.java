interface TrafficLightState {
    void display();
    void switchState(TrafficLight trafficLight);
}