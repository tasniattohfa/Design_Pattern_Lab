interface FileSystemVisitable {
    void accept(FileSystemVisitor visitor);
}